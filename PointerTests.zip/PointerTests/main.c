/*********************************************************************
* Project: PointerTests
* File: main.c
* Author: Gwen Montague
* Date: 10/21/2020
* Description: This is a console-based program that tests using
*              pointers
*********************************************************************/
#include <stdio.h>
#include <stdlib.h>
int main()
{
    int x = 12;
    printf("%d\n", x);
    printf("%p\n", &x);
    printf("%s\n", "--------------------------------------");
    double values[] = {1.1, 1.2, 1.3, 1.4, 1.5, 1.6, 1.7};
    printf("%p\n", values);
    printf("%lf\n", *values);
    printf("%p\n", (values + 2));
    printf("%lf\n", *(values + 2));
    printf("%d\n", sizeof(double));
    printf("%s\n", "--------------------------------------");
    int num = 12;
    int* ptr = &num;
    int** pptr = &ptr;
    printf("num = %d\n", num);
    printf("ptr = %p\n", ptr);
    printf("*ptr = %d\n", *ptr);
    printf("pptr = %p\n", pptr);
    printf("*pptr = %p\n", *pptr);
    printf("**pptr = %d\n", **pptr);
}
